def rectangle(w,h):
   area = w*h
   return area
   
def circle(r):
   import math
   area = math.pi*math.pow(r,2)
   return area