def sum(x,y):
   val = x+y
   return val
   
def average(x,y):
   val = (x+y)/2
   return val

def power(x,y):
   val = x**y
   return val